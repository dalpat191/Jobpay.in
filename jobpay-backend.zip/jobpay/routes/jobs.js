const router = require('express').Router();
const Job = require('../models/Job');
const Company = require('../models/Company');
const { protect, allowRoles } = require('../middleware/auth');

// SEARCH: GET /api/jobs?q=react&location=pune&minSalary=300000&skills=node,react&page=1&limit=10
router.get('/', async (req, res, next) => {
  try {
    const { q, location, minSalary, jobType, skills, page = 1, limit = 10 } = req.query;
    const filter = { isActive: true };
    if (q) filter.$text = { $search: q };
    if (location) filter.location = new RegExp(location, 'i');
    if (jobType) filter.jobType = jobType;
    if (minSalary) filter.salaryMax = { $gte: Number(minSalary) };
    if (skills) filter.skills = { $in: skills.split(',').map((s) => new RegExp(`^${s.trim()}$`, 'i')) };

    const skip = (Number(page) - 1) * Number(limit);
    const [jobs, total] = await Promise.all([
      Job.find(filter).populate('company', 'name logoUrl').sort('-createdAt').skip(skip).limit(Number(limit)),
      Job.countDocuments(filter)
    ]);
    res.json({ total, page: Number(page), pages: Math.ceil(total / limit), jobs });
  } catch (e) { next(e); }
});

// Recruiter: apni jobs (/:id se pehle rakhna zaroori hai)
router.get('/mine/list', protect, allowRoles('recruiter'), async (req, res, next) => {
  try { res.json(await Job.find({ postedBy: req.user._id }).sort('-createdAt')); }
  catch (e) { next(e); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id).populate('company');
    if (!job) return res.status(404).json({ message: 'Job not found' });
    res.json(job);
  } catch (e) { next(e); }
});

// Recruiter: post job (company auto-create agar nahi hai)
router.post('/', protect, allowRoles('recruiter'), async (req, res, next) => {
  try {
    let companyId = req.user.company;
    if (!companyId) {
      const { companyName } = req.body;
      if (!companyName) return res.status(400).json({ message: 'companyName required for first job' });
      const company = await Company.create({ name: companyName, owner: req.user._id });
      req.user.company = companyId = company._id;
      await req.user.save();
    }
    const { companyName, ...data } = req.body;
    const job = await Job.create({ ...data, company: companyId, postedBy: req.user._id });
    res.status(201).json(job);
  } catch (e) { next(e); }
});

router.put('/:id', protect, allowRoles('recruiter'), async (req, res, next) => {
  try {
    const job = await Job.findOneAndUpdate(
      { _id: req.params.id, postedBy: req.user._id }, req.body, { new: true, runValidators: true });
    if (!job) return res.status(404).json({ message: 'Job not found or not yours' });
    res.json(job);
  } catch (e) { next(e); }
});

router.delete('/:id', protect, allowRoles('recruiter', 'admin'), async (req, res, next) => {
  try {
    const filter = req.user.role === 'admin' ? { _id: req.params.id } : { _id: req.params.id, postedBy: req.user._id };
    const job = await Job.findOneAndDelete(filter);
    if (!job) return res.status(404).json({ message: 'Job not found or not yours' });
    res.json({ message: 'Job deleted' });
  } catch (e) { next(e); }
});

module.exports = router;

const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const { protect } = require('../middleware/auth');

const sign = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

router.post('/register',
  body('name').notEmpty(),
  body('email').isEmail(),
  body('password').isLength({ min: 6 }),
  body('role').isIn(['jobseeker', 'recruiter']),
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

      const { name, email, password, role } = req.body;
      if (await User.findOne({ email })) return res.status(409).json({ message: 'Email already registered' });

      const user = await User.create({ name, email, role, password: await bcrypt.hash(password, 12) });
      res.status(201).json({ token: sign(user._id), user: { id: user._id, name, email, role } });
    } catch (e) { next(e); }
  });

router.post('/login',
  body('email').isEmail(),
  body('password').notEmpty(),
  async (req, res, next) => {
    try {
      const user = await User.findOne({ email: req.body.email }).select('+password');
      if (!user || !(await bcrypt.compare(req.body.password, user.password)))
        return res.status(401).json({ message: 'Invalid email or password' });
      res.json({ token: sign(user._id), user: { id: user._id, name: user.name, email: user.email, role: user.role } });
    } catch (e) { next(e); }
  });

router.get('/me', protect, (req, res) => res.json(req.user));

router.put('/profile', protect, async (req, res, next) => {
  try {
    const { name, profile } = req.body;
    if (name) req.user.name = name;
    if (profile) req.user.profile = { ...req.user.profile?.toObject?.(), ...profile };
    await req.user.save();
    res.json(req.user);
  } catch (e) { next(e); }
});

module.exports = router;

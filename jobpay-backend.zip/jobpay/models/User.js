const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, minlength: 6, select: false },
  role: { type: String, enum: ['jobseeker', 'recruiter', 'admin'], default: 'jobseeker' },
  company: { type: mongoose.Schema.Types.ObjectId, ref: 'Company' }, // recruiters only
  profile: {
    headline: String,
    location: String,
    skills: [String],
    resumeUrl: String,
    experience: [{
      title: String, company: String, from: Date, to: Date, description: String
    }],
    education: [{ degree: String, institute: String, year: Number }]
  }
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);

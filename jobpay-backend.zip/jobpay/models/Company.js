const mongoose = require('mongoose');

module.exports = mongoose.model('Company', new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  website: String,
  logoUrl: String,
  description: String,
  location: String,
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
}, { timestamps: true }));

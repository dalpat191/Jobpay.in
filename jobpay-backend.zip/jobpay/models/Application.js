const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema({
  job: { type: mongoose.Schema.Types.ObjectId, ref: 'Job', required: true },
  applicant: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  resumeUrl: String,
  coverNote: String,
  status: { type: String, enum: ['applied', 'shortlisted', 'rejected', 'hired'], default: 'applied' }
}, { timestamps: true });

// Duplicate application rokne ke liye
applicationSchema.index({ job: 1, applicant: 1 }, { unique: true });

module.exports = mongoose.model('Application', applicationSchema);
